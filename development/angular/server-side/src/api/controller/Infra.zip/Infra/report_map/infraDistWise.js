const router = require('express').Router();
var const_data = require('../../../lib/config');
const { logger } = require('../../../lib/logger');
const auth = require('../../../middleware/check-auth');
const fs = require('fs');
router.post('/distWise', auth.authController, function (req, res) {
    try {
        logger.info('---Infra dist wise api ---');
        const_data['getParams']['Key'] = `infra/infra_district.json`;
        const_data['s3'].getObject(const_data['getParams'], function (err, data) {
            if (err) {
                logger.error(err);
                res.status(500).json({ errMsg: "Something went wrong" });
            } else if (!data) {
                logger.error("No data found in s3 file");
                res.status(403).json({ errMsg: "No such data found" });
            } else {
                logger.info('--- Infra dist wise api response sent ---');
                var mydata = [
                    {
                        "district_name": "Kachchh",
                        "district_id": "2401",
                        "lat": 23.256836,
                        "lng": 69.68125,
                        "infra_score": 95.8,
                        "handwash_percent": 87.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Banaskantha",
                        "district_id": "2402",
                        "lat": 24.195774,
                        "lng": 72.028885,
                        "infra_score": 93.8,
                        "handwash_percent": 95.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Patan",
                        "district_id": "2403",
                        "lat": 23.831957,
                        "lng": 72.117905,
                        "infra_score": 90.8,
                        "handwash_percent": 93.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Mahesana",
                        "district_id": "2404",
                        "lat": 23.58065,
                        "lng": 72.38779,
                        "infra_score": 87.3,
                        "handwash_percent": 79.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Sabar Kantha",
                        "district_id": "2405",
                        "lat": 23.822697,
                        "lng": 72.9895,
                        "infra_score": 91.9,
                        "handwash_percent": 89.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Gandhinagar",
                        "district_id": "2406",
                        "lat": 23.20534,
                        "lng": 72.64207,
                        "infra_score": 85.3,
                        "handwash_percent": 97.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    },
                    {
                        "district_name": "Ahemadabad",
                        "district_id": "2407",
                        "lat": 23.019894,
                        "lng": 72.60421,
                        "infra_score": 92.7,
                        "handwash_percent": 91.43,
                        "solar_panel_percent": 97.7,
                        "library_percent": 95.4,
                        "drining_water_percent": 97.13,
                        "tap_water_percent": 94.83,
                        "hand_pumps_percent": 96.55,
                        "electricity_percent": 97.7,
                        "toilet_percent": 96.55,
                        "boys_toilet_percent": 95.4,
                        "girls_toilet_percent": 95.98,

                    }
                ]
                res.status(200).send(mydata);
            }
        });
    } catch (e) {
        logger.error(`Error :: ${e}`)
        res.status(500).json({ errMessage: "Internal error. Please try again!!" });
    }
});

module.exports = router;